# MAFIS course presentation

- `MAFIS_AI_Project.pptx`: 16 slides with embedded notes, editable workflow shapes, tables, a retrieval chart and an animated demo.
- `slide_blueprint.md`: exact copy, visual placement, and notes for all 16 slides. The demo notes explain what to point out during playback.
- `build_deck.py`: recreates the deck and blueprint with python-pptx. Its source files and assets are all local.
- `generate_simulation.py`: converts the saved NVIDIA correction trace into a looping GIF. Start Slide Show on slide 13 to see it play; if your viewer displays only a still, open `assets/nvidia_correction.gif`.
- `generate_charts.py`: exports transparent retrieval and timing PNGs for reuse, and crops the original NVIDIA PDF row embedded on slide 4. The deck uses native editable evidence for the retrieval chart and the timing table.
- `diagrams/*.dot`: Graphviz source for preprocessing/retrieval, orchestration and the correction trace. The rendered SVGs are separate, and the PowerPoint workflow remains editable.

## Rebuild from the MAFIS root

```powershell
python -m pip install -r presentation/requirements.txt
python presentation/generate_charts.py
python presentation/generate_simulation.py
Push-Location presentation
npm ci
npm run diagrams
Pop-Location
python presentation/build_deck.py
```

Python builds the PowerPoint; Node/npm is only needed for regenerating the optional SVGs. The Python scripts read the checked-in summary in `evaluation/results.md`, the fixture manifest and cited PDF, and the saved local offline run under `output/batch2/demo`. The closeout results are historical. These commands replay the saved evidence and do not run a live model or rerun the closeout study.

If the local demo directory is absent (for example, on a fresh checkout), regenerate the NVIDIA traces using the repository's Python environment and the real local Chroma/MiniLM retriever. Mock generation requires no API key. The embedder can need an initial model download if it is not already cached:

```powershell
.\.venv\Scripts\python.exe -m scripts.batch2_demo --case-ids nvidia_2024 --output output/batch2/demo
```

For a separate demo directory, pass `--demo-dir path/to/demo` to both asset generators. The standalone GIF script validates the gate, retry, verification and net-margin records before making frames.

The course's grading instructions are in `report things/Final Guidelines.docx.pdf`. The accompanying `reportformat.pdf` is a sample written report. The course literature comparison is on slide 11, and slides 2 and 7 cover state space and the equivalent input constraints. The only pre-existing PNG, `useful_md_files/mafis_architecture_preview.png`, is a design draft with DCF, valuation and news labels outside the implemented scope. Slide 6 replaces it with the verified graph. There were no saved empirical PNG/JPG plots in the project.
