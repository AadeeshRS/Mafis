"""Build the editable, 16-slide MAFIS course deck and its matching blueprint."""
from argparse import ArgumentParser
from pathlib import Path
import re

from PIL import Image
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_TICK_MARK
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Inches, Pt

from evidence import ASSETS, HERE, closeout

W, H = 13 + 1/3, 7.5
M = .64
FONT = "Arial"
BG, WHITE, INK, MUTED = "F6F8FC", "FFFFFF", "141F34", "4E5E78"
DARK, LIGHT, RULE = "101A2D", "C3CDE0", "D9E0EC"
TEAL, INDIGO = "097769", "4D51C5"
TEAL_LIGHT, INDIGO_LIGHT = "E1F2EF", "E9EAFB"
MINT, PERI = "49DCC0", "A6A9FE"
BANNED = ("delve,tapestry,testament,underscores,pivotal,crucial,landscape,realm,foster,beacon,"
          "intricate,meticulous,leverage,utilize,harness,elevate,streamline,embark,myriad,plethora,"
          "game-changer,cutting-edge,state-of-the-art,revolutionize,seamless,robust,in conclusion,"
          "furthermore,moreover").split(",")


def rgb(color):
    return RGBColor.from_string(color)


def pt(value):
    return Inches(value)


def text_style(p, size, color, bold=False, align=PP_ALIGN.LEFT):
    p.font.name = FONT
    p.font.size = Pt(size)
    p.font.bold = bold
    p.font.color.rgb = rgb(color)
    p.alignment = align
    p.space_before, p.space_after, p.line_spacing = Pt(0), Pt(0), 1.07


class Deck:
    def __init__(self, assets):
        self.p = Presentation()
        self.p.slide_width, self.p.slide_height = pt(W), pt(H)
        props = self.p.core_properties
        props.title = "MAFIS | Multi-Agent Financial Intelligence System"
        props.subject = "Artificial Intelligence course project"
        props.keywords = "financial filings; evidence verification; retrieval; LangGraph"
        self.assets, self.records = assets, []

    def box(self, x, y, w, h, fill, line=None, shape=MSO_SHAPE.RECTANGLE):
        s = self.s.shapes.add_shape(shape, pt(x), pt(y), pt(w), pt(h))
        style = s._element.find("{http://schemas.openxmlformats.org/presentationml/2006/main}style")
        if style is not None:
            s._element.remove(style)
        if fill:
            s.fill.solid()
            s.fill.fore_color.rgb = rgb(fill)
        else:
            s.fill.background()
        if line:
            s.line.color.rgb = rgb(line)
            s.line.width = Pt(1)
        else:
            s.line.fill.background()
        return s

    def line(self, x1, y1, x2, y2, color=RULE, *, width=1, arrow=False):
        s = self.s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, pt(x1), pt(y1), pt(x2), pt(y2))
        style = s._element.find("{http://schemas.openxmlformats.org/presentationml/2006/main}style")
        if style is not None:
            s._element.remove(style)
        s.line.color.rgb, s.line.width = rgb(color), Pt(width)
        if arrow:
            end = OxmlElement("a:tailEnd")
            end.set("type", "triangle")
            s.line._get_or_add_ln().append(end)
        return s

    def register(self, text):
        if text:
            self.records[-1]["text"].append(text)

    def tx(self, content, x, y, w, h=.42, size=20, color=INK, *, bold=False,
           align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.MIDDLE, record=True, wrap=False):
        s = self.s.shapes.add_textbox(pt(x), pt(y), pt(w), pt(h))
        self.fill_text(s.text_frame, content, size, color, bold, align, anchor, wrap)
        if record:
            self.register(content)
        return s

    @staticmethod
    def fill_text(tf, text, size, color, bold=False, align=PP_ALIGN.LEFT,
                  anchor=MSO_ANCHOR.MIDDLE, wrap=False):
        tf.clear()
        tf.word_wrap, tf.vertical_anchor = wrap, anchor
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        for index, line in enumerate(text.split("\n")):
            p = tf.paragraphs[0] if index == 0 else tf.add_paragraph()
            p.text = line
            text_style(p, size, color, bold, align)

    def slide(self, title, layout, placement, notes, sources=(), *, dark=False, cover=False):
        self.s = self.p.slides.add_slide(self.p.slide_layouts[6])
        self.records.append(dict(title=title, layout=layout, placement=placement,
                                 notes=notes, sources=sources, text=[], image_text=[]))
        bg = self.s.background.fill
        bg.solid()
        bg.fore_color.rgb = rgb(DARK if dark else BG)
        number = len(self.records)
        if not cover:
            self.tx(title, M, .50, 12, .79, 32, WHITE if dark else INK, bold=True)
        self.line(M, 7.03, W-M, 7.03, "3B4860" if dark else RULE)
        self.tx(f"{number:02}", W-1.17, 7.08, .53, .28, 11,
                LIGHT if dark else MUTED, align=PP_ALIGN.RIGHT, record=False)
        self.s.notes_slide.notes_text_frame.text = notes + ("\n\nSources: " + "\n".join(sources) if sources else "")

    def node(self, content, x, y, w, h=.78, *, tone="indigo", size=17):
        fill, fg = {"indigo": (INDIGO_LIGHT, INDIGO), "teal": (TEAL_LIGHT, TEAL),
                    "neutral": (WHITE, INK), "dark": (DARK, WHITE)}[tone]
        s = self.box(x, y, w, h, fill, RULE if tone == "neutral" else None)
        self.fill_text(s.text_frame, content, size, fg, True, PP_ALIGN.CENTER)
        self.register(content)

    def flow(self, labels, y, *, x=M, w=12.05, gap=.27, h=.83, tones=None, size=17):
        width = (w - gap * (len(labels) - 1)) / len(labels)
        for i in range(len(labels) - 1):
            end = x + (i + 1) * (width + gap)
            self.line(end-gap+.035, y+h/2, end-.035, y+h/2, MUTED, arrow=True)
        for i, label in enumerate(labels):
            self.node(label, x + i*(width+gap), y, width, h,
                      tone=tones[i] if tones else "indigo", size=size)

    def metrics(self, pairs, y, *, left=M, total=12.05, size=62):
        step = total / len(pairs)
        for i, (n, caption) in enumerate(pairs):
            x = left + step*i
            if i:
                self.line(x-.2, y+.07, x-.2, y+1.38)
            self.tx(n, x, y, step-.27, 1, size, TEAL if i == 0 else INDIGO, bold=True)
            self.tx(caption, x, y+1.08, step-.27, .42, 18, MUTED)

    def table(self, rows, x, y, widths, row_h, font=17, *, center=(), highlight=(), header=True):
        table = self.s.shapes.add_table(len(rows), len(widths), pt(x), pt(y), pt(sum(widths)),
                                        pt(len(rows)*row_h)).table
        table.first_row = table.first_col = table.horz_banding = table.vert_banding = False
        for col, width in zip(table.columns, widths):
            col.width = pt(width)
        for i, row in enumerate(rows):
            table.rows[i].height = pt(row_h)
            assert len(row) == len(widths)
            for j, value in enumerate(row):
                cell = table.cell(i, j)
                is_header = header and i == 0
                fill = DARK if is_header else TEAL_LIGHT if i in highlight else WHITE if i % 2 else "EDF1F8"
                color = WHITE if is_header else TEAL if i in highlight else INK
                cell.fill.solid()
                cell.fill.fore_color.rgb = rgb(fill)
                cell.margin_left = cell.margin_right = pt(.14)
                cell.margin_top = cell.margin_bottom = 0
                cell.vertical_anchor = MSO_ANCHOR.MIDDLE
                self.fill_text(cell.text_frame, value, font, color, is_header or i in highlight,
                               PP_ALIGN.CENTER if j in center else PP_ALIGN.LEFT)
                self.register(value)

    def pic(self, name, x, y, width, height=None, *, alt="", image_text=()):
        path = self.assets / name
        if not path.is_file():
            raise FileNotFoundError(f"{path}: run the asset generation commands in README.md")
        with Image.open(path) as im:
            natural = width*im.height/im.width
        if height is not None and natural > height:
            new_width = width*height/natural
            x += (width-new_width)/2
            width, natural = new_width, height
        pic = self.s.shapes.add_picture(str(path), pt(x), pt(y), width=pt(width), height=pt(natural))
        pic._element.nvPicPr.cNvPr.set("descr", alt)
        self.records[-1]["image_text"].extend(image_text)
        return pic

    def retrieval(self, labels, values, x, y, w, h):
        data = CategoryChartData()
        data.categories = labels
        data.add_series("Queries", values)
        chart = self.s.shapes.add_chart(XL_CHART_TYPE.BAR_CLUSTERED, pt(x), pt(y), pt(w), pt(h), data).chart
        chart.has_legend = chart.has_title = False
        plot = chart.plots[0]
        plot.gap_width = 85
        chart.category_axis.reverse_order = True
        chart.category_axis.tick_labels.font.name = FONT
        chart.category_axis.tick_labels.font.size = Pt(18)
        chart.category_axis.tick_labels.font.color.rgb = rgb(INK)
        chart.category_axis.major_tick_mark = chart.category_axis.minor_tick_mark = XL_TICK_MARK.NONE
        chart.category_axis.format.line.fill.background()
        chart.value_axis.minimum_scale = 0
        chart.value_axis.maximum_scale = 34
        chart.value_axis.visible = False
        chart.value_axis.has_major_gridlines = False
        for i, point in enumerate(chart.series[0].points):
            point.format.fill.solid()
            point.format.fill.fore_color.rgb = rgb(TEAL if i == 0 else INDIGO)
        plot.has_data_labels = True
        dl = plot.data_labels
        dl.show_value, dl.position = True, XL_LABEL_POSITION.OUTSIDE_END
        dl.font.name, dl.font.size, dl.font.bold = FONT, Pt(18), True
        dl.font.color.rgb = rgb(INK)
        for label, value in zip(labels, values):
            self.register(f"{label} {value}")

    def save(self, output, blueprint):
        assert len(self.p.slides) == len(self.records) == 16
        md = ["# MAFIS slide blueprint", "",
              "16 slides, 16:9. Arial throughout. Graphite and off-white with teal and indigo accents. "
              "The two-digit footer is present on every slide and included in the word count.", "",
              "Rubric: `report things/Final Guidelines.docx.pdf`. "
              "`report things/reportformat.pdf` is a sample report, with no slide layout to copy.", ""]
        for i, r in enumerate(self.records, 1):
            visible = [*r["text"], f"{i:02}"]
            fixed, alternatives = [], []
            for item in r["image_text"]:
                (alternatives if isinstance(item, tuple) else fixed).append(item)
            longest = max(alternatives, key=lambda a: len(" ".join(a).split()), default=())
            n = len(" ".join([*visible, *fixed, *longest]).split())
            assert n < 40, (i, n, visible)
            for word in BANNED:
                assert not re.search(rf"\b{re.escape(word)}\b", " ".join([*visible, *fixed, *longest]), re.I), (i, word)
            md += [f"## {i:02}. {r['title']}", "", f"**Layout:** {r['layout']}", "",
                   f"**Placement:** {r['placement']}", "", f"**Exact visible text** ({n} words"
                   + (", longest animation frame included" if alternatives else "") + "):", "", "```text",
                   *visible, *fixed, "```", ""]
            if alternatives:
                md += ["Embedded GIF text by frame (the final frame holds briefly):", "", "```text"]
                md += [" / ".join(a) for a in alternatives] + ["```", ""]
            md += ["**Speaker notes:** " + r["notes"], ""]
            md += ["**Sources:** " + " · ".join(f"`{s}`" if not s.startswith("https://") else f"<{s}>"
                                              for s in r["sources"]), ""]
        output.parent.mkdir(parents=True, exist_ok=True)
        blueprint.parent.mkdir(parents=True, exist_ok=True)
        self.p.save(output)
        blueprint.write_text("\n".join(md), encoding="utf-8")


def build(assets):
    d = closeout()
    a = d["arms"]
    z = Deck(assets)
    result = "evaluation/results.md"
    graph = "graph.py"

    z.slide("MAFIS", "Dark typographic split.", "Name and problem at left; retrieval headline on the right.",
            "Our project asks whether a report about a company can show exactly where its financial claims came from. "
            "MAFIS turns a filing and a question into a traceable analysis. Our strongest measured retrieval result is "
            "28 page hits across 30 labelled queries using real MiniLM embeddings. This is a retrieval result on exposed "
            "queries. It does not tell us how often the complete report is correct.",
            (result, "Readme.md", "evaluation/batch2.py::score_retrieval"), dark=True, cover=True)
    z.tx("ARTIFICIAL INTELLIGENCE COURSE PROJECT", M, 1.09, 7, .35, 14, PERI, bold=True)
    z.tx("MAFIS", M-.04, 1.58, 7, 1.68, 97, WHITE, bold=True)
    z.tx("Multi-Agent Financial\nIntelligence System", M, 3.25, 7, 1.27, 34, WHITE, bold=True)
    z.tx("Trace financial claims to filings", M, 5.14, 7, .47, 21, LIGHT)
    z.line(7.85, 1.66, 7.85, 5.94, "3B4860")
    z.tx(f"{d['pages'][0]}/{d['pages'][1]}", 8.29, 2.21, 4.47, 1.36, 77, MINT, bold=True)
    z.tx("labelled queries hit the right page\nin the top five", 8.32, 3.65, 4.37, .89, 21, WHITE)

    z.slide("Financial analysis as a state graph", "Three state blocks and two outcome paths.",
            "Left-to-right state progression, with success and partial outcomes below the terminal state.",
            "Think of a state as everything the run knows so far. Initially we have the question, filing metadata and an "
            "empty run store. LangGraph actions retrieve, propose and verify evidence, compute ratios or rerun a dependency. "
            "The current state includes claims, issues and retry budget. We aim for a traceable report, but the graph also "
            "terminates with an honest partial report. It follows coded conditions, so a shortest-path search would not "
            "fit this task. The actual search is for source chunks, which I’ll show later.",
            (graph + "::Phase1State, ExtendedState, run_full_pipeline", "agents/planner.py::PlannerAgent"))
    z.flow(["Initial state", "Working state", "Terminal state"], 2.19, gap=.52, h=.87,
           tones=["neutral","indigo","teal"], size=21)
    z.tx("Question + filing\nEmpty run store", M+.13, 3.32, 3.4, .92, 22)
    z.tx("Versioned claims\nOpen issues\nRetry budget", 4.30+.52, 3.26, 3.6, 1.22, 22)
    z.tx("Traceable report\nPartial if unresolved", 8.98, 3.32, 3.55, .92, 22)
    z.line(M, 5.26, W-M, 5.26)
    z.tx("Actions: retrieve, verify, calculate, retry", M, 5.57, 11, .43, 22, MUTED)

    z.slide("Seven filings support all four calculations", "Three metric columns and nested coverage bar.",
            "Counts across the top. Lower bar partitions the 13 source slots into admitted, local unsupported and blocked downloads.",
            "The manifest reserves thirteen company slots. Ten official PDFs are present, and seven pass the extraction "
            "profile for all six required primitive values. The remaining three local PDFs do not. The dated market input is "
            "the January 31, 2024 FOMC statement excerpt. Amazon, Meta and PepsiCo were moved into development for parser work; "
            "AMD is validation and parser-development material. We cannot treat the successful cases as a fresh held-out set.",
            ("tests/fixtures/batch2_cases.json", "tests/fixtures/market_snapshots/fomc_2024_01_31.json", result))
    z.metrics([(str(d["slots"]), "requested source slots"), (str(d["local"]), "local official PDFs"),
               (str(d["supported"]), "admitted filings")], 1.84)
    x = M
    for n, label, color in [(d["supported"],"Admitted", TEAL), (d["local"]-d["supported"],"Local unsupported", INDIGO),
                            (d["slots"]-d["local"],"Blocked downloads", "A7B3CB")]:
        width = (W-2*M)*n/d["slots"]
        z.box(x, 4.06, width, .43, color)
        z.tx(f"{n} {label}", x+.02, 4.68, width-.04, .37, 16, MUTED, align=PP_ALIGN.CENTER)
        x += width
    z.tx("Market context: 31 Jan 2024 FOMC snapshot", M, 5.85, 12, .50, 20, MUTED)

    z.slide("A claim keeps its source and version", "Source strip above a three-column record.",
            "NVIDIA revenue row cropped from the filing above editable value, fiscal context and provenance fields.",
            "Here is the actual source line from NVIDIA's income statement. For the January 28, 2024 column the parsed "
            "value is 60,922 in USD millions. The indexed TableCell retains the metric, accounting scope, fiscal period, "
            "scale and evidence location. The agent's Claim has a stable ID and an incrementing version. SharedMemory "
            "appends revisions and keeps the exact references. A calculation can become stale if one of its source "
            "versions changes, so verification is a property of a specific version.",
            ("tests/fixtures/nvidia_2024/annual_report.pdf, PDF p. 150 (printed p. 50)", "rag/models.py::TableCell",
             "memory/shared_memory.py::Evidence, Claim, ClaimVersionRef, SharedMemory"))
    z.tx("NVIDIA FY2024 income statement", M, 1.86, 11, .44, 21, INDIGO, bold=True)
    z.box(M, 2.63, W-2*M, .79, WHITE, RULE)
    z.pic("nvidia_revenue_row.png", M+.35, 2.88, W-2*M-.7, .30,
          alt="Source crop: Revenue $60,922 $26,974 $26,914",
          image_text=("Revenue $ 60,922 $ 26,974 $ 26,914",))
    z.metrics([("60,922", "USD millions"), ("28 Jan 2024", "Fiscal year end"),
               ("PDF p. 150", "Cell locator")], 4.07, size=37)
    z.tx("SharedMemory: claim ID + version", M, 6.23, 12, .48, 19, MUTED)

    z.slide("PDF parsing preserves table context", "Two parallel native workflow lanes.",
            "Narrative and statement routes meet the same index. Measured character window settings sit below the narrative lane.",
            "The ingest code reads born-digital PDFs with pdfplumber. It makes page-bounded narrative chunks using "
            "900-character windows with 150 characters of overlap, plus section windows of 800 and 100. It also attaches "
            "the table title, fiscal headers, scale header and exact quote to supported statement rows. It resolves "
            "comparative dates and currency only when the source gives enough context. Narrative can still be searchable "
            "when a table is not admissible. This path has no OCR.",
            ("rag/ingest.py::prepare_document, extract_financial_facts, chunk_text", "requirements-extraction.txt"))
    z.flow(["Born-digital PDF", "Page text", "Narrative chunks", "Chroma index"], 2.03, gap=.48,
           tones=["neutral","indigo","indigo","teal"], size=18)
    z.tx("Chars / overlap: page 900/150 · section 800/100", 3.80, 3.18, 8.65, .49, 19, MUTED)
    z.flow(["Statement rows", "Dates + scale", "Typed cells", "Chroma index"], 4.46, gap=.48,
           tones=["neutral","indigo","indigo","teal"], size=18)

    z.slide("Verification controls the report path", "Top evidence chain and bottom conditional branch.",
            "Native connectors show the evidence chain, reasoning path, and Planner's shared correction before reporting.",
            "The upper row compresses the first part of the full graph. It verifies primitives before Financial runs, "
            "checks the Financial and dated Market outputs before Risk, then verifies Risk before the Health Gate. "
            "A pass can start Bull and Bear on the same eligible snapshot, then the Critic checks structured assertions. "
            "A blocked gate bypasses that stage. Planner combines eligible issues from the gate and Critic, allows one "
            "targeted rerun, and the ReportAgent renders the authoritative AnalysisMap. A clean run goes straight to reporting "
            "after the Planner's retry check.",
            (graph + "::build_extended_graph, build_full_graph", "agents/full_workflow.py::requests_for, execute_targeted",
             "agents/report_agent.py::ReportAgent"))
    z.flow(["Planner", "Document\n+ verify", "Financial\n+ dated Market", "Verify, Risk\n+ verify", "Health Gate"],
           1.84, h=.97, size=16, tones=["neutral","indigo","indigo","indigo","teal"])
    y = 4.05
    for x1,x2 in [(3.31,3.77),(6.66,7.11),(9.57,10.03)]:
        z.line(x1, y+.44, x2, y+.44, MUTED, arrow=True)
    z.line(11.59, 2.82, 11.59, 3.20, MUTED)
    z.line(11.59, 3.20, 1.97, 3.20, MUTED)
    z.line(1.97, 3.20, 1.97, y-.04, MUTED, arrow=True)
    z.line(5.22, 3.20, 5.22, y-.04, MUTED, arrow=True)
    z.tx("Pass", 2.04, 3.32, 1.0, .32, 13, TEAL, bold=True)
    z.tx("Blocked", 5.31, 3.32, 1.2, .32, 13, INDIGO, bold=True)
    z.node("Bull/Bear + Critic", M, y, 2.67, .88, size=16)
    z.node("Planner retry check", 3.80, y, 2.86, .88, tone="teal", size=16)
    z.node("Targeted rerun", 7.14, y, 2.43, .88, tone="teal", size=16)
    z.node("Analysis map\n+ report", 10.06, y, 2.63, .88, tone="dark", size=16)
    z.line(5.22, y+.89, 5.22, 5.78, MUTED)
    z.line(5.22, 5.78, 11.37, 5.78, MUTED)
    z.line(11.37, 5.78, 11.37, y+.91, MUTED, arrow=True)
    z.tx("No rerun", 7.08, 5.87, 2.2, .36, 15, MUTED)

    z.slide("Models propose; code checks and calculates", "Two columns split by responsibility.",
            "Model role labels on the left. Deterministic checks and operation family on the right.",
            "The production adapter asks Gemini for typed proposals. The Document and Financial agents select source facts "
            "and operations, while Bull and Bear select qualified interpretations. The Critic's optional language call can "
            "explain a finding; rules detect the structured contradiction. Verification checks the source quote and cell "
            "attributes. FinancialEngine accepts only revenue growth, operating margin, net margin and current ratio, using "
            "Decimal over checked input versions. In CSP terms, the variables are operation input roles, their domains are "
            "retrieved typed cells, and the constraints include metric, period, currency, unit, version and source identity. "
            "The code filters and validates these selections directly; it has no general CSP solver, fuzzy inference or "
            "unrestricted search over assignments. Support labels describe evidence, not calibrated probabilities.",
            ("gemini.py::GeminiAdapter", "agents/document_agent.py::DocumentAgent",
             "agents/financial_agent.py::FinancialAgent", "agents/critic_agent.py::CriticAgent",
             "agents/verification_agent.py::VerificationAgent", "engine/financial_engine.py::FinancialEngine"))
    z.line(6.64, 1.85, 6.64, 6.30)
    z.tx("Gemini proposals", M, 1.88, 5.75, .61, 27, INDIGO, bold=True)
    z.tx("Document: source cell selection\nFinancial: operation selection\nBull/Bear: qualified interpretations",
         M, 2.83, 5.75, 1.68, 21)
    z.tx("Python rules", 7.04, 1.88, 5.55, .61, 27, TEAL, bold=True)
    z.tx("Verifier: exact evidence checks\nFinancialEngine: Decimal arithmetic\nCritic: structured contradictions",
         7.04, 2.83, 5.65, 1.68, 21)
    z.tx("Constraints: metric, period, currency, version", 7.04, 5.38, 5.65, .45, 17, MUTED)

    z.slide("Search ranks evidence within source filters", "Four-stage retrieval strip with result callouts.",
            "Editable flow across the canvas; per-query k and index behavior below.",
            "SharedRetriever embeds on CPU with Chroma’s ONNX MiniLM implementation and searches the persistent Chroma "
            "collection with cosine distance. It can restrict results by document, section, chunk kind, page, period or "
            "metric, and uses chunk ID to break equal distances. DocumentAgent runs three narrative queries at top 3 and "
            "metric-specific table queries at top 5, then deduplicates chunks. State routing is rule-based and neither "
            "embedding nor generation model is trained or fine-tuned by this repository.",
            ("config.py::EMBEDDING_MODEL", "rag/retriever.py::SharedRetriever.retrieve",
             "agents/document_agent.py::collect_context"))
    z.flow(["Query", "all-MiniLM-L6-v2", "Filtered Chroma", "Cosine-ranked\nchunks"],
           2.04, gap=.47, h=1.01, tones=["neutral","indigo","indigo","teal"], size=18)
    z.metrics([("3", "hits per narrative query"), ("5", "hits per metric query")], 3.95, size=57)
    z.tx("No project-side model training", M, 6.31, 12, .44, 18, MUTED)

    z.slide("The Health Gate has an uncalibrated default", "Three parameter columns above a calibration strip.",
            "Production gate, shared retry budget and default adapter controls. Injected threshold sweep in a separate line.",
            "By default, VerificationHealthGate blocks if the fraction of current factual claims ineligible as verified "
            "is strictly greater than 0.5. Empty evidence or any upstream issue blocks regardless of that rate. "
            "The one retry is analytical; it is separate from the adapter's two default transport retries. The production "
            "Gemini default is gemini-3.8-flash with temperature zero, 4096 output tokens and a 30-second timeout. "
            "The injected validation sweep runs from 0 to 1 in increments of 0.25. It minimizes false passes, then "
            "false blocks, then chooses the smaller threshold. It selected 0.25 on four synthetic rows and did not "
            "change the production value.",
            ("config.py", "gemini.py::GeminiSettings", "agents/verification_gate.py::VerificationHealthGate",
             "evaluation/mechanisms.py", "evaluation/batch2.py::freeze_threshold"))
    z.metrics([(">0.5", "ineligible rate blocks"), ("1", "analytical retry maximum"),
               ("0", "Gemini temperature")], 1.99)
    z.tx("Empty evidence or upstream issues block", M, 4.23, 12, .44, 21, bold=True)
    z.tx("Adapter: 4096 tokens, 30 s, 2 transport retries", M, 5.11, 12, .37, 18)
    z.tx("Injected sweep: 0–1 by 0.25", M, 5.84, 12, .40, 18, MUTED)

    z.slide("Page hits outnumber passage hits", "Editable bar chart left; two validation counts right.",
            "Native horizontal bars with a 30-query denominator. Source-cell and engine totals sit in a separate right column.",
            "The closeout used real MiniLM and labelled development queries. A page hit means one of the five retrieved "
            "chunks landed on a labelled page. Anchor coverage additionally asks whether a retrieved chunk contains the "
            "labelled passage. The logged counts were 28 of 30 for pages and 26 of 30 for anchors; the study did not measure "
            "six unindexed or unadmitted cases. Separately, the seven admitted documents gave 42 source-matching primitives "
            "and 28 correctly computed engine operations. The oracle computes independently using rational arithmetic.",
            (result, "evaluation/batch2.py::score_retrieval", "evaluation/metrics.py::expectations",
             "tests/fixtures/retrieval_validation.json"))
    z.tx(f"{d['pages'][1]} labelled development queries · top 5", M, 1.70, 7.45, .47, 19, MUTED)
    z.retrieval(["Page hit", "Anchor passage"], [d["pages"][0], d["anchors"][0]], M, 2.28, 7.62, 3.58)
    z.line(8.61, 1.74, 8.61, 6.33)
    z.tx(str(d["cells"]), 9.06, 1.99, 3.6, 1.06, 60, TEAL, bold=True)
    z.tx("source-matching cells", 9.10, 3.02, 3.56, .42, 19, MUTED)
    z.tx(str(d["engine_ops"]), 9.06, 4.13, 3.6, 1.06, 60, INDIGO, bold=True)
    z.tx("correct engine operations", 9.10, 5.15, 3.56, .42, 19, MUTED)

    z.slide("Full and single-call arms tie with mocks", "Baseline grid left; related-work comparison right.",
            "Requested numerical slots for the two repo arms on the left. Scope comparison to two research references on the right.",
            "The repository baseline makes one call without the engine, verifier or Critic. The arms share a question and "
            "prebuilt filing and Fed evidence bundle. Specialists can retrieve additional scoped chunks, so their contexts "
            "are comparable in access, not identical. Both mock arms return the same 28 correct values across 52 requested "
            "slots. That is not measured live accuracy. For context, FinanceBench evaluates open-book financial questions, "
            "and FinCARDS reranks finance-aware evidence cards. Our system emphasizes checked claims and report generation. "
            "We did not run either publication's benchmark.",
            (result, "evaluation/batch2.py::CommonEvidence, validate_pair", "evaluation/full_baseline.py",
             "https://arxiv.org/abs/2311.11944", "https://aclanthology.org/2026.findings-acl.1244/"))
    z.table([["Offline arm","Correct/requested"],
             ["Full",f"{a['full'][2]}/{a['full'][3]}"],["Single call",f"{a['single_llm'][2]}/{a['single_llm'][3]}"]],
            M, 2.34, [2.12,3.15], .77, 18, center=(1,), highlight=(1,))
    z.table([["Related work","Focus"], ["FinanceBench ’23","Open-book QA"], ["FinCARDS ’26","Evidence reranking"],
             ["MAFIS","Verified reports"]], 6.42, 2.34, [2.61,3.65], .77, 18, highlight=(3,))
    z.tx("Comparable source access", M, 5.11, 5.51, .41, 17, MUTED)

    z.slide("Missing source context blocks extraction", "Failure examples left; injected confusion matrices right.",
            "Three issuer-level failures. Two editable matrices with predicted columns (positive, negative) and actual rows (positive, negative).",
            "Intel's glyphs became readable, but the parser still lacked reporting currency. Walmart's statement fonts "
            "did not supply a usable Unicode mapping, and Nike also had no separately reported operating-income line. "
            "These are admission failures, not fabricated zeros. On the right are small injected tests of implemented "
            "rules: Verifier detects all eight injected errors and leaves one clean case alone. Critic catches seven "
            "structured contradictions and leaves five compatible cases alone. Rows are actual and columns predicted, "
            "positive first. These matrices cannot establish accuracy on free-form text.",
            (result, "tests/fixtures/batch2_cases.json", "evaluation/mechanisms.py", "evaluation/batch2.py::detection_metrics"))
    for i, (name, issue) in enumerate([("Intel", "Currency unestablished"), ("Walmart", "Unsupported text encoding"),
                                       ("Nike", "No separate operating income")]):
        y = 1.94 + i*1.28
        z.tx(name, M, y, 5.27, .45, 22, bold=True)
        z.tx(issue, M, y+.51, 5.27, .39, 19, MUTED)
        if i < 2:
            z.line(M, y+1.02, 5.93, y+1.02)
    z.line(6.13, 1.83, 6.13, 6.29)
    z.tx("Injected cases", 6.48, 1.96, 6, .49, 22, INDIGO, bold=True)
    for i, name in enumerate(("Verifier","Critic")):
        x = 6.48 + i*3.15
        m = d["injected"][name]
        z.tx(name, x, 2.71, 2.81, .43, 17, bold=True)
        z.table([[str(m["tp"]),str(m["fn"])],[str(m["fp"]),str(m["tn"])]],
                x, 3.26, [1.41,1.40], .61, 22, center=(0,1), header=False)
    z.tx("Actual × predicted, positive first", 6.48, 5.15, 6, .42, 16, MUTED)

    z.slide("One retry recovers NVIDIA’s net margin", "Embedded GIF left, outcome contrast right.",
            "Left: assets/nvidia_correction.gif, animated during Slide Show. Right: persistent-omission outcome.",
            "In this saved offline demo, the model double omits net income on its first pass. The Health Gate blocks because "
            "a required primitive is missing. Watch Planner spend its single retry, Document recover the source cell, and "
            "FinancialEngine compute the exact net margin from verified inputs. The report succeeds. When the same double "
            "omits it again in the persistent scenario, the budget is exhausted and the report stays partial. We replay the "
            "exported gate history; the real filing and retrieval are paired with mocked generation.",
            ("scripts/batch2_demo.py", "output/batch2/demo/nvidia_2024_corrected/evidence.json",
             "output/batch2/demo/nvidia_2024_persistent/run_summary.json"), dark=True)
    milestones = "Omission Gate Planner Recheck Report"
    z.pic("nvidia_correction.gif", M, 2.08, 8.75, alt="Animated replay of a saved NVIDIA offline correction",
          image_text=tuple((f"STEP {i:02} / 05", head, detail, milestones) for i, (head, detail) in
                           enumerate([("Net income omitted","First model response"),("Health Gate blocks","Required evidence missing"),
                                      ("Planner allocates retry","Budget: 1 to 0"),("Net income verified","Financial Engine recomputes"),
                                      ("48.8493% net margin","Gate passes · report succeeds")], 1)))
    z.line(9.64, 2.20, 9.64, 5.97, "43526D")
    z.tx("Offline replay", 9.98, 2.39, 2.55, .42, 21, MINT, bold=True)
    z.tx("Persistent omission:\npartial report", 9.98, 3.35, 2.7, .92, 20, WHITE)

    z.slide("Ablations preserve the mock score", "Large outcome at left; component evidence at right.",
            "Mock score and totals on the left; behavior changes hard-coded by two representative interventions on the right.",
            "The eight conditions were the full graph, single call, no verifier, no Bull/Bear, no Critic, no reanalysis, "
            "no engine and a unified analyst. Each completes on seven admitted filings and retains six source failures. "
            "All eight score 28 correct known slots out of 52 requested; the 28 returned scorable values are all correct. "
            "Removing verification keeps the unchecked path from fabricating check records. Removing the engine changes "
            "arithmetic to model output and drops calculation artifacts. The other interventions also change executed stages "
            "or consolidate role calls. These changes were exercised, but identical mock answers tell us nothing about "
            "which components improve live accuracy.",
            (result, "evaluation/batch2.py::CONDITIONS, _run_condition", "evaluation/experimental.py::no_engine_run",
             "evaluation/unified.py::unified_run"))
    z.tx(f"{a['full'][2]}/{a['full'][3]}", M, 1.97, 5.22, 1.53, 88, TEAL, bold=True)
    z.tx("Correct/requested in all 8 arms", M, 3.61, 5.78, .55, 22, bold=True)
    z.tx("56 completions · 48 source failures", M, 4.56, 5.84, .53, 19, MUTED)
    z.line(6.70, 1.88, 6.70, 6.27)
    z.tx("Without verification", 7.15, 2.17, 5.4, .49, 23, INDIGO, bold=True)
    z.tx("Unchecked claims", 7.15, 2.82, 5.4, .46, 19)
    z.tx("Without engine", 7.15, 4.08, 5.4, .49, 23, INDIGO, bold=True)
    z.tx("Mock arithmetic · no calculation artifacts", 7.15, 4.73, 5.51, .45, 18)

    z.slide("Mean local inference time", "Editable timing table left; latency caveats right.",
            "All eight arms listed with aggregate logical mock calls and mean local inference seconds. Timing limits at right.",
            "The full condition made 56 mock logical requests across seven completed documents, compared with seven for "
            "the single-call comparator. The full arm's mean was 24.147 seconds versus 0.007 seconds for the single call. "
            "These are reported local inference times under concurrent validation load. The baseline reuses prepared context, "
            "while the full graph does additional scoped retrieval and validation. This is not a controlled overall latency "
            "benchmark. Peak RAM and live inference timing were not measured, and all arms have identical mock numerical scores.",
            (result, "evaluation/batch2.py::run_condition", "evaluation/metrics.py::condition_usage"))
    labels = ["Full", "Single-call", "No-verifier", "No-Bull/Bear", "No-Critic", "No-reanalysis", "No-engine", "Unified"]
    rows = [["Arm","Calls","Seconds"]] + [[label,str(arm[4]),f"{arm[5]:.3f}"]
                                         for label, arm in zip(labels, a.values())]
    z.table(rows, M, 1.63, [3.05,1.29,2.09], .55, 16, center=(1,2), highlight=(1,))
    z.line(7.52, 1.78, 7.52, 6.49)
    z.tx("Mock runs", 7.94, 2.51, 4.7, .62, 29, INDIGO, bold=True)
    z.tx("Memory unmeasured\nLive latency unknown", 7.94, 3.53, 4.70, 1.13, 22)

    z.slide("Live quality remains unmeasured", "Dark closing slide with three limitation-to-next-step rows.",
            "Evidence limits left and proposed follow-up actions aligned to the right.",
            "The attempted live comparator got HTTP 503 and no completed live pair. We need paired runs with the same model "
            "settings, logged retrieval and controlled timing and memory measurement. We also have no completed human "
            "ratings. Two reviewers should independently assess blinded reports and trace claims to the original sources, "
            "then compare results on untouched filings. Right now the parser's admission rules exclude some issuer formats; "
            "test new currency and encoding handling on separate data before expansion. Showing missing evidence matters "
            "because readers could otherwise mistake a limited risk screen for complete or actionable financial advice.",
            (result, "tests/fixtures/batch2_cases.json", "evaluation/batch2.py::human_materials, import_ratings"),
            dark=True)
    for i, (issue, action) in enumerate([("HTTP 503 · no live pair", "Run a controlled paired trial"),
                                         ("Zero human ratings", "Blind-review untouched filings"),
                                         ("Encoding and currency gaps", "Validate parser changes separately")]):
        y = 1.95 + i*1.44
        z.tx(issue, M, y, 5.88, .65, 24, WHITE, bold=True)
        z.tx(action, 7.02, y, 5.64, .65, 21, MINT)
        if i < 2:
            z.line(M, y+1.02, W-M, y+1.02, "3B4860")
    return z


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=ASSETS)
    parser.add_argument("--output", type=Path, default=HERE / "MAFIS_AI_Project.pptx")
    parser.add_argument("--blueprint", type=Path, default=HERE / "slide_blueprint.md")
    args = parser.parse_args()
    build(args.assets).save(args.output, args.blueprint)
